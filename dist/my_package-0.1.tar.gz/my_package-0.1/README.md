# my_package
This library was created as an example of how to publish my own Python package.

# How to install
...